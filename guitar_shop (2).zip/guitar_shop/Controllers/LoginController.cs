using Microsoft.AspNetCore.Mvc;

namespace guitar_shop.Controllers;

public class LoginController : Controller
{
    public IActionResult Index()
    {
        ViewData["Title"] = "Войти";
        return View();
    }

    [HttpPost]
    public IActionResult Index(string username, string password)
    {
        if (!string.IsNullOrWhiteSpace(username) && password == "123456")
        {
            HttpContext.Session.SetString("User", username);
            return RedirectToAction("Index", "Home");
        }
        ViewBag.Error = "Неверный логин или пароль";
        return View();
    }
    
    public IActionResult Logout()
    {
        HttpContext.Session.Remove("User");
        return RedirectToAction("Index", "Home");
    }
}