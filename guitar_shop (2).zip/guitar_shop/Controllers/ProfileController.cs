using Microsoft.AspNetCore.Mvc;

namespace guitar_shop.Controllers;

public class ProfileController : Controller
{
    public IActionResult Index()
    {
        ViewData["Title"] = "Профиль";
        return View();
    }
}