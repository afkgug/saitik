using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using guitar_shop.Models;

namespace guitar_shop.Controllers;

public class OrderController : Controller
{
    private const string CartSessionKey = "CartItems";

    public IActionResult Index()
    {
        ViewData["Title"] = "Оформление заказа";
        var json = HttpContext.Session.GetString(CartSessionKey);
        var cart = json != null ? JsonSerializer.Deserialize<List<CartItem>>(json) : new List<CartItem>();
        return View(cart);
    }

    [HttpPost]
    public IActionResult Index(string name, string email, string address)
    {
        // Placeholder for order processing
        HttpContext.Session.Remove(CartSessionKey);
        ViewData["Success"] = true;
        return View(new List<CartItem>());
    }
}