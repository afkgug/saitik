using Microsoft.AspNetCore.Mvc;

namespace guitar_shop.Controllers;

public class RegisterController : Controller
{
    public IActionResult Index()
    {
        ViewData["Title"] = "Регистрация";
        return View();
    }

    [HttpPost]
    public IActionResult Index(string username, string email, string password)
    {
        if (password.Length < 6)
        {
            ViewBag.Error = "Пароль слишком короткий";
            return View();
        }

        ViewBag.Success = "На вашу почту отправлено письмо для подтверждения.";
        return View();
    }
}